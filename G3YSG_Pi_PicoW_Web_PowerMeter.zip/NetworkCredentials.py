class NetworkCredentials:
    ssid = 'YourNetworkName'
    password = 'YourPassword'
    #ssid = 'G3YSG'
    #password = 'Mike12345'
